Sound pack downloaded from Freesound
----------------------------------------

This pack of sounds contains sounds by the following user:
 - Jaz_the_MAN_2 ( https://freesound.org/people/Jaz_the_MAN_2/ )

You can find this pack online at: https://freesound.org/people/Jaz_the_MAN_2/packs/17749/

License details
---------------

Creative Commons 0: http://creativecommons.org/publicdomain/zero/1.0/


Sounds in this pack
-------------------

  * 316913__jaz-the-man-2__si.wav
    * url: https://freesound.org/s/316913/
    * license: Creative Commons 0
  * 316912__jaz-the-man-2__sol.wav
    * url: https://freesound.org/s/316912/
    * license: Creative Commons 0
  * 316911__jaz-the-man-2__sol-stretched.wav
    * url: https://freesound.org/s/316911/
    * license: Creative Commons 0
  * 316910__jaz-the-man-2__si-stretched.wav
    * url: https://freesound.org/s/316910/
    * license: Creative Commons 0
  * 316909__jaz-the-man-2__re-stretched.wav
    * url: https://freesound.org/s/316909/
    * license: Creative Commons 0
  * 316908__jaz-the-man-2__re.wav
    * url: https://freesound.org/s/316908/
    * license: Creative Commons 0
  * 316907__jaz-the-man-2__mi-stretched.wav
    * url: https://freesound.org/s/316907/
    * license: Creative Commons 0
  * 316906__jaz-the-man-2__mi.wav
    * url: https://freesound.org/s/316906/
    * license: Creative Commons 0
  * 316905__jaz-the-man-2__fa-stretched.wav
    * url: https://freesound.org/s/316905/
    * license: Creative Commons 0
  * 316904__jaz-the-man-2__fa.wav
    * url: https://freesound.org/s/316904/
    * license: Creative Commons 0
  * 316903__jaz-the-man-2__la-stretched.wav
    * url: https://freesound.org/s/316903/
    * license: Creative Commons 0
  * 316902__jaz-the-man-2__la.wav
    * url: https://freesound.org/s/316902/
    * license: Creative Commons 0
  * 316901__jaz-the-man-2__do-octave.wav
    * url: https://freesound.org/s/316901/
    * license: Creative Commons 0
  * 316900__jaz-the-man-2__do-stretched-octave.wav
    * url: https://freesound.org/s/316900/
    * license: Creative Commons 0
  * 316899__jaz-the-man-2__do-stretched.wav
    * url: https://freesound.org/s/316899/
    * license: Creative Commons 0
  * 316898__jaz-the-man-2__do.wav
    * url: https://freesound.org/s/316898/
    * license: Creative Commons 0


